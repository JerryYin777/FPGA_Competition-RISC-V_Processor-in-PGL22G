#include <stdint.h>

#include "../include/timer.h"
#include "../include/gpio.h"
#include "../include/utils.h"
#include "../include/uart.h"
#include "../include/xprintf.h"


static volatile uint32_t count;


int main()
{
	uint32_t a=0;
    count = 0;
    uart_init();
    xprintf("ssss");

#ifdef SIMULATION
	xprintf("cccc");
    TIMER0_REG(TIMER0_VALUE) = 500;     // 10us period
    TIMER0_REG(TIMER0_CTRL) = 0x07;     // enable interrupt and start timer
    xprintf("oooo");

    while (1) {
        if (count == 2) {
            TIMER0_REG(TIMER0_CTRL) = 0x00;   // stop timer
            count = 0;
            // TODO: do something
//            set_test_pass();
            xprintf("xxxx");
            break;
        }
    }
#else
    TIMER0_REG(TIMER0_VALUE) = 500000;  // 10ms period
    xprintf("aaaa");
    TIMER0_REG(TIMER0_CTRL) = 0x07;     // enable interrupt and start timer
    xprintf("bbbb");

//    GPIO_REG(GPIO_CTRL) |= 0x1;  // set gpio0 output mode

    while (1) {
    	a++;
//        if (a%10==0){
        //xprintf("count:%d,a:%d",count,a);
//		}
		// 500ms
        if (count == 50) {
        	xprintf("count:%d,a:%d",count,a);
            count = 0;
//            uart_init();
            xprintf("111111111111\n"); // toggle led
        }
    }
#endif

    return 0;
}

void timer0_irq_handler()
{
    TIMER0_REG(TIMER0_CTRL) |= (1 << 2) | (1 << 0);  // clear int pending and start timer

    count++;
}
