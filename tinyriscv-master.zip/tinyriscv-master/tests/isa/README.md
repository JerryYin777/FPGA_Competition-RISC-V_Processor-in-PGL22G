RV32I instruction source code which copy from riscv(github).
I have modified it so can run on tinyriscv.
compile: type make under the cmd windows
recompile: type make after make clean under the cmd windows
